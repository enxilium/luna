"""Shared MCP runtime: connection lifetime, schemas, tool execution, and auth results."""

import asyncio
import hashlib
import os
import re
import tomllib
from contextlib import AsyncExitStack
from dataclasses import dataclass
from pathlib import Path

import httpx2
from loguru import logger
from mcp import Client, StdioServerParameters
from mcp.client.streamable_http import streamable_http_client
from mcp.client.stdio import stdio_client
from mcp.types import InputRequiredResult, TextContent, Tool
from pipecat.adapters.schemas.direct_function import tool_options
from pipecat.adapters.schemas.function_schema import FunctionSchema
from pipecat.adapters.schemas.tools_schema import ToolsSchema
from pipecat.frames.frames import FunctionCallResultProperties
from pipecat.frames.frames import LLMContextFrame
from pipecat.processors.frame_processor import FrameProcessor
from pipecat.services.llm_service import FunctionCallParams

from src.integrations.auth import AuthAdapter, AuthFailure, AuthOutcome, MCPOAuthAdapter
from src.integrations.spotify import SpotifyAuthAdapter
from src.integrations.catalog import CatalogTool, model_schema, schema_size, search, service_words, text_replacement_tool, words


CONFIG_PATH = Path.home() / "Library/Application Support/Luna/mcp.toml"
AUTH_TIMEOUT = 295.0  # Leave five seconds for cleanup before Pipecat's 300-second deadline.
MAX_ACTIVE_TOOLS = 6
MAX_TOOL_SCHEMA_BYTES = 8000

INTEGRATION_INSTRUCTIONS = (
    "Use currently enabled integration tools directly for service requests. Before invoking tools, "
    "narrate one short complete sentence of intent, then call tools. "
    "Search only when no enabled tool fits. search_tools enables tools; its result is not task completion. "
    "Continue until actual service results answer the request. "
    "For complex batch updates, get_tool_help supplies operation guidance. "
    "If invalid_arguments is returned, consult help and correct the call. Do not repeat completed edits; verify with a read. "
    "When a tool returns auth_required, explain sign-in and call authorize_integration. "
    "While awaiting_authorization, do not retry service tools or start another login; keep talking. "
    "Only connected confirms authorization. Then continue the still-relevant task using tools; "
    "if the request changed, ask whether to continue. Respect denied, failed, timed_out and cancelled. "
    "Never claim success without a tool result. Never read structured tool data aloud verbatim."
)


@dataclass
class MCPIntegration:
    integration_id: str
    description: str
    server: str | StdioServerParameters
    auth: AuthAdapter | None = None
    tools: list[str] | None = None


class _Connection:
    def __init__(self, integration: MCPIntegration):
        self.integration = integration
        self.client: Client | None = None
        self.error: BaseException | None = None
        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()
        self._lock = asyncio.Lock()
        self._operation_lock = asyncio.Lock()

    async def start(self) -> Client:
        async with self._lock:
            if self.client is not None:
                return self.client
            if self._task:
                await self._task
            self.error = None
            self._stop = asyncio.Event()
            ready = asyncio.get_running_loop().create_future()
            self._task = asyncio.create_task(self._own(ready), name=f"mcp:{self.integration.integration_id}")
            try:
                return await asyncio.shield(ready)
            except asyncio.CancelledError:
                self._task.cancel()
                await asyncio.gather(self._task, return_exceptions=True)
                raise

    async def _own(self, ready):
        try:
            async with AsyncExitStack() as stack:
                server, auth = self.integration.server, self.integration.auth
                if isinstance(server, str):
                    http = await stack.enter_async_context(httpx2.AsyncClient(
                        auth=auth.http_auth if auth else None, timeout=30, follow_redirects=False,
                    ))
                    server = streamable_http_client(server, http_client=http)
                else:
                    errlog = stack.enter_context(open(os.devnull, "w"))
                    server = stdio_client(server, errlog=errlog)
                self.client = await stack.enter_async_context(Client(server, cache=None, read_timeout_seconds=30))
                ready.set_result(self.client)
                await self._stop.wait()
        except BaseException as error:
            self.error = error
            if not ready.done():
                ready.set_exception(error)
                ready.exception()
        finally:
            self.client = None

    async def close(self):
        async with self._lock:
            if self._task:
                self._task.cancel()
                await asyncio.gather(self._task, return_exceptions=True)
                self._task = None
            self.client = None


class _MCPSchema(FunctionSchema):
    """Preserve the complete MCP JSON schema, including definitions and constraints."""

    def __init__(self, name, tool: Tool, handler, description=None):
        self.input_schema = tool.input_schema
        super().__init__(name, description or tool.description or tool.name,
                         tool.input_schema.get("properties", {}), tool.input_schema.get("required", []), handler)

    def to_default_dict(self):
        return super().to_default_dict() | {"parameters": model_schema(self.input_schema)}


def _causes(error):
    if isinstance(error, BaseExceptionGroup):
        for child in error.exceptions:
            yield from _causes(child)
    else:
        yield error


class MCPRuntime:
    def __init__(self, integrations: list[MCPIntegration]):
        ids = [i.integration_id for i in integrations]
        if len(set(ids)) != len(ids) or any(not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", i) for i in ids):
            raise ValueError("Integration IDs must be unique lowercase names of at most 32 characters")
        self.integrations = {i.integration_id: i for i in integrations}
        self._connections = {i.integration_id: _Connection(i) for i in integrations}
        self._discovered: dict[str, list[Tool]] = {}
        self._routes: dict[str, tuple[str, str]] = {}
        self._catalog: dict[str, CatalogTool] = {}
        self._active: dict[str, str] = {}
        self._pending_queries: dict[str, str] = {}
        self._authorizing: dict[str, asyncio.Task] = {}
        self._closed = False

    @classmethod
    def from_config(cls, path: Path = CONFIG_PATH):
        if not path.exists():
            return cls([])
        try:
            config = tomllib.loads(path.read_text())
        except (ValueError, OSError):
            logger.warning("MCP configuration could not be read; integrations are disabled")
            return cls([])
        integrations = []
        entries = config.get("integrations", {})
        if not isinstance(entries, dict):
            logger.warning("Invalid MCP configuration; integrations are disabled")
            return cls([])
        for integration_id, entry in entries.items():
            try:
                if not isinstance(entry, dict):
                    raise ValueError("Integration settings must be a table")
                if not isinstance(entry.get("description", integration_id), str):
                    raise ValueError("description must be text")
                if "url" in entry:
                    if not isinstance(entry["url"], str) or "command" in entry:
                        raise ValueError("Specify one transport")
                    from src.integrations.auth import validate_http_url
                    validate_http_url(entry["url"])
                    server = entry["url"]
                else:
                    server = StdioServerParameters(
                        command=str(Path(entry["command"]).expanduser()), args=entry.get("args", []),
                        cwd=str(Path(entry["cwd"]).expanduser()) if entry.get("cwd") else None,
                    )
                kind = entry.get("auth", "none")
                if kind == "mcp_oauth" and isinstance(server, str):
                    adapter = MCPOAuthAdapter(
                        server, redirect_uri=entry.get("redirect_uri", "http://127.0.0.1:8765/oauth/callback"),
                        client_id=entry.get("client_id"), scopes=entry.get("scopes"),
                        authorization_params=entry.get("authorization_params"),
                    )
                elif kind == "spotify" and isinstance(server, StdioServerParameters) and server.cwd:
                    adapter = SpotifyAuthAdapter(Path(server.cwd), server.command)
                elif kind == "none":
                    adapter = None
                else:
                    raise ValueError("Unsupported authentication/transport combination")
                if "tools" in entry and (not isinstance(entry["tools"], list)
                                        or any(not isinstance(t, str) for t in entry["tools"])):
                    raise ValueError("tools must be a list")
                if not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", integration_id):
                    raise ValueError("Invalid integration ID")
                integrations.append(MCPIntegration(
                    integration_id, entry.get("description", integration_id), server, adapter, entry.get("tools"),
                ))
            except (ValueError, KeyError, TypeError):
                logger.warning("Skipping invalid MCP integration configuration")
        return cls(integrations)

    async def __aenter__(self):
        await asyncio.gather(*(self.connect(i) for i in self.integrations))
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        self._closed = True
        tasks = [t for t in self._authorizing.values() if t is not asyncio.current_task()]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        await asyncio.gather(*(c.close() for c in self._connections.values()))

    def _failure(self, integration_id, error) -> dict:
        adapter = self.integrations[integration_id].auth
        errors = list(_causes(error))
        safe = next((e for e in errors if isinstance(e, AuthFailure)), None)
        if safe:
            return AuthOutcome("failed", str(safe)).as_dict(integration_id)
        if adapter:
            for cause in errors:
                required = adapter.classify_failure(cause)
                if required:
                    return AuthOutcome("auth_required", required.reason).as_dict(integration_id)
        logger.warning("MCP integration '{}' failed ({})", integration_id, type(errors[0]).__name__)
        return AuthOutcome("failed", "integration_unavailable").as_dict(integration_id)

    async def connect(self, integration_id: str) -> dict:
        if not isinstance(integration_id, str) or integration_id not in self.integrations:
            return AuthOutcome("failed", "unknown_integration").as_dict(integration_id)
        if self._closed:
            return AuthOutcome("failed", "runtime_closed").as_dict(integration_id)
        if (integration_id in self._authorizing
                and self._authorizing[integration_id] is not asyncio.current_task()):
            return AuthOutcome("awaiting_authorization").as_dict(integration_id)
        connection = self._connections[integration_id]
        try:
            async with asyncio.timeout(30):
                client = await connection.start()
                self._discovered[integration_id] = (await client.list_tools()).tools
                self._refresh_catalog(integration_id)
            return AuthOutcome("connected").as_dict(integration_id)
        except Exception as error:
            cause = connection.error or error
            await connection.close()
            return self._failure(integration_id, cause)

    async def call_tool(self, integration_id: str, name: str, arguments: dict) -> dict:
        integration = self.integrations.get(integration_id)
        if integration and integration.tools is not None and name not in integration.tools:
            return AuthOutcome("failed", "unknown_tool").as_dict(integration_id)
        if integration_id in self._authorizing:
            return AuthOutcome("awaiting_authorization").as_dict(integration_id)
        connection = self._connections.get(integration_id)
        connected = (AuthOutcome("connected").as_dict(integration_id)
                     if not self._closed and connection and connection.client
                     and integration_id in self._discovered else await self.connect(integration_id))
        if connected["status"] != "connected":
            return connected
        integration = self.integrations[integration_id]
        allowed = {t.name for t in self._discovered[integration_id]
                   if integration.tools is None or t.name in integration.tools}
        if name not in allowed:
            return AuthOutcome("failed", "unknown_tool").as_dict(integration_id)
        connection = self._connections[integration_id]
        try:
            entry = next(e for e in self._catalog.values()
                         if e.integration_id == integration_id and e.tool.name == name)
            invalid = entry.invalid_arguments(arguments)
            if invalid:
                return {"status": "failed", "integration": integration_id, **invalid}
            async with connection._operation_lock:
                result = await connection.client.session.call_tool(name, arguments, allow_input_required=True)
            if isinstance(result, InputRequiredResult):
                return AuthOutcome("failed", "unsupported_auth_interaction").as_dict(integration_id)
            required = integration.auth.classify_failure(result) if integration.auth else None
            if required:
                return AuthOutcome("auth_required", required.reason).as_dict(integration_id)
            return {
                "status": "failed" if result.is_error else "completed",
                "integration": integration_id,
                "content": [c.model_dump(mode="json") for c in result.content if isinstance(c, TextContent)],
                "structured_content": result.structured_content,
            }
        except Exception as error:
            cause = connection.error or error
            await connection.close()
            return self._failure(integration_id, cause)

    async def authorize(self, integration_id: str, report_progress) -> dict:
        if not isinstance(integration_id, str) or integration_id not in self.integrations:
            return AuthOutcome("failed", "unknown_integration").as_dict(integration_id)
        if self._closed:
            return AuthOutcome("failed", "runtime_closed").as_dict(integration_id)
        if integration_id in self._authorizing:
            return AuthOutcome("awaiting_authorization").as_dict(integration_id)
        adapter = self.integrations[integration_id].auth
        if adapter is None:
            return await self.connect(integration_id)
        self._authorizing[integration_id] = asyncio.current_task()
        try:
            await self._connections[integration_id].close()
            async with asyncio.timeout(AUTH_TIMEOUT):
                result = await adapter.authorize(report_progress)
                if result.status != "connected":
                    return result.as_dict(integration_id)
                return await self.connect(integration_id)
        except TimeoutError:
            return AuthOutcome("timed_out").as_dict(integration_id)
        except Exception as error:
            return self._failure(integration_id, error)
        finally:
            self._authorizing.pop(integration_id, None)

    def _refresh_catalog(self, integration_id):
        old = {name for name, entry in self._catalog.items() if entry.integration_id == integration_id}
        allowed = self.integrations[integration_id].tools
        current = {}
        for tool in self._discovered[integration_id]:
            if allowed is not None and tool.name not in allowed:
                continue
            name = f"{integration_id}__{tool.name}"
            if len(name) > 64 or not re.fullmatch(r"[A-Za-z0-9_-]+", name):
                name = f"{integration_id}__{hashlib.sha256(tool.name.encode()).hexdigest()[:24]}"
            current[name] = CatalogTool(name, integration_id, tool)
            self._routes[name] = (integration_id, tool.name)
        for entry in list(current.values()):
            facade = text_replacement_tool(entry.tool)
            if facade and f"{integration_id}__{facade.name}" not in current:
                name = f"{integration_id}__{facade.name}"
                current[name] = CatalogTool(name, integration_id, facade)
                self._routes[name] = (integration_id, entry.tool.name)
        for name in old - current.keys():
            self._catalog.pop(name)
            self._routes.pop(name, None)
            self._active.pop(name, None)
        self._catalog.update(current)

    def _matching_services(self, query):
        tokens = words(query)
        return [i for i, integration in self.integrations.items()
                if tokens & service_words(i, integration.description)]

    def _select(self, query, integration_ids=None):
        entries = [entry for entry in self._catalog.values()
                   if integration_ids is None or entry.integration_id in integration_ids]
        selected = search(entries, query)[:3]
        prerequisites = {"replace_text": "read_doc", "update_doc": "read_doc", "update_presentation": "read_presentation",
                         "update_spreadsheet": "get_spreadsheet"}
        for entry in list(selected):
            read = prerequisites.get(entry.tool.name)
            if read:
                selected.extend(e for e in entries if e.integration_id == entry.integration_id
                                and e.tool.name == read and e not in selected)
        candidates = dict(self._active)
        candidates.update({e.name: query for e in selected})
        keep, size = set(), 0
        for name in [e.name for e in selected] + list(candidates):
            if name in keep or name not in self._catalog:
                continue
            cost = schema_size(self._catalog[name], candidates[name])
            # ponytail: byte budget estimates tokens; use tokenizer counts if measurements need tighter bounds.
            if keep and (len(keep) >= MAX_ACTIVE_TOOLS or size + cost > MAX_TOOL_SCHEMA_BYTES):
                continue
            keep.add(name)
            size += cost
        self._active = {name: text for name, text in candidates.items() if name in keep}
        return [e for e in selected if e.name in keep]

    def prepare_context(self, context):
        messages = context.get_messages()
        if messages and messages[-1].get("role") == "user":
            query = messages[-1].get("content")
            if isinstance(query, str):
                services = self._matching_services(query)
                if len(services) == 1:
                    self._select(query, services)
        context.set_tools(self.tools_schema())

    def system_instruction(self):
        return INTEGRATION_INSTRUCTIONS

    def tools_schema(self) -> ToolsSchema:
        if not self.integrations:
            return ToolsSchema([])
        ids = list(self.integrations)
        descriptions = "; ".join(f"{i}: {s.description}" for i, s in self.integrations.items())
        properties = {"integration_id": {"type": "string", "enum": ids}}
        controls = [
            FunctionSchema("connect_integration", "Connect and refresh a configured service's tool catalog.",
                           properties, ["integration_id"], self._connect_tool),
            FunctionSchema("authorize_integration", "Sign in to a configured service when auth_required is returned. "
                           "Wait for completion before retrying service tools.",
                           properties, ["integration_id"], self._authorize_tool),
        ]
        schemas = [
            FunctionSchema("search_tools", f"Find and enable tools for a task. Describe the service and action. {descriptions}",
                           {"query": {"type": "string"}}, ["query"], self._search_tool),
            FunctionSchema("get_tool_help", "Load exact operation guidance for an enabled tool. Specify an operation name or describe the change. Omit operation only to request the complete manual.",
                           {"tool_name": {"type": "string"}, "operation": {"type": "string"}},
                           ["tool_name"], self._help_tool),
            *controls,
        ]
        for name, query in self._active.items():
            entry = self._catalog[name]
            schemas.append(_MCPSchema(name, entry.tool, self._service_tool, entry.description(query)))
        return ToolsSchema(schemas)

    async def _search_tool(self, params: FunctionCallParams):
        query = params.arguments.get("query")
        if not isinstance(query, str) or not query.strip():
            await params.result_callback({"status": "failed", "reason": "query_required"})
            return
        services = self._matching_services(query)
        failures = []
        for integration_id in services or self.integrations:
            if integration_id not in self._discovered:
                self._pending_queries[integration_id] = query
                connected = await self.connect(integration_id)
                if connected["status"] != "connected":
                    failures.append(connected)
        selected = self._select(query, services or None)
        params.context.set_tools(self.tools_schema())
        result = {"status": "tools_available" if selected else "no_matching_tools",
                  "tools": [{"name": e.name, "description": e.summary} for e in selected],
                  "integrations": failures}
        if not selected and len(failures) == 1:
            result.update(failures[0])
        await params.result_callback(result)

    async def _help_tool(self, params: FunctionCallParams):
        entry = self._catalog.get(params.arguments.get("tool_name"))
        operation = params.arguments.get("operation", "")
        if entry is None or not isinstance(operation, str):
            await params.result_callback({"status": "failed", "reason": "unknown_tool",
                                         "available_tools": list(self._active)})
            return
        self._select(entry.name + " " + operation, [entry.integration_id])
        if entry.name not in self._active:
            await params.result_callback({"status": "failed", "reason": "tool_not_selected"})
            return
        self._active[entry.name] = operation
        params.context.set_tools(self.tools_schema())
        await params.result_callback({"status": "tools_available", "tool_name": entry.name,
                                     "guidance": entry.description(operation) if operation else entry.tool.description})

    def _select_connected(self, params, integration_id):
        messages = params.context.get_messages()
        query = next((m.get("content") for m in reversed(messages)
                      if m.get("role") == "user" and isinstance(m.get("content"), str)), "")
        query = query or self._pending_queries.get(integration_id, self.integrations[integration_id].description)
        self._select(query + " " + integration_id, [integration_id])
        self._pending_queries.pop(integration_id, None)

    async def _connect_tool(self, params: FunctionCallParams):
        result = await self.connect(params.arguments.get("integration_id"))
        if result["status"] == "connected":
            self._select_connected(params, result["integration"])
        self.prepare_context(params.context)
        await params.result_callback(result)

    @tool_options(cancel_on_interruption=False, cancellable_by_llm=True, timeout_secs=300)
    async def _authorize_tool(self, params: FunctionCallParams):
        integration_id = params.arguments.get("integration_id")

        async def report(update):
            await params.result_callback(update | {"integration": integration_id}, properties=
                                         FunctionCallResultProperties(is_final=False, run_llm=True))

        result = await self.authorize(integration_id, report)
        if result["status"] == "connected":
            self._select_connected(params, integration_id)
        self.prepare_context(params.context)
        await params.result_callback(result, properties=FunctionCallResultProperties(run_llm=True))

    async def _service_tool(self, params: FunctionCallParams):
        await params.result_callback(await self._invoke_tool(params.function_name, params.arguments))

    async def _invoke_tool(self, name, arguments):
        if not isinstance(arguments, dict):
            return {"status": "failed", "reason": "invalid_arguments"}
        route = self._routes.get(name)
        arguments = dict(arguments)
        entry = self._catalog.get(name)
        if route and entry and entry.tool.name == "replace_text" and route[1] == "update_doc":
            invalid = entry.invalid_arguments(arguments)
            if invalid:
                return {"status": "failed", **invalid}
            arguments = {"documentId": arguments["documentId"], "requests": [{"replaceAllText": {
                "containsText": {"text": arguments["findText"], "matchCase": arguments["matchCase"]},
                "replaceText": arguments["replaceText"],
            }}]}
        return await self.call_tool(*route, arguments) if route else {
            "status": "failed", "reason": "unknown_tool",
        }


class IntegrationToolsProcessor(FrameProcessor):
    def __init__(self, runtime: MCPRuntime):
        super().__init__()
        self.runtime = runtime

    async def process_frame(self, frame, direction):
        await super().process_frame(frame, direction)
        if isinstance(frame, LLMContextFrame):
            self.runtime.prepare_context(frame.context)
        await self.push_frame(frame, direction)
