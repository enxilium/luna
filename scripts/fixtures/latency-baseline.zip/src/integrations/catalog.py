"""Local tool search and model-facing guidance; canonical schemas stay intact."""

import json
import math
import re
import copy
from dataclasses import dataclass
from functools import cached_property

from jsonschema import Draft202012Validator
from mcp.types import Tool


_ALIASES = {
    "get": "read", "show": "read", "check": "read", "fetch": "read",
    "next": "list", "upcoming": "list", "find": "search", "lookup": "search",
    "add": "create", "new": "create", "edit": "update", "change": "update",
    "doc": "document", "docs": "document", "sheet": "spreadsheet",
    "slide": "presentation", "gmail": "email", "mail": "email",
}
_STOP = set("a an the my me i you your to of in on for with from at and or it all please google tool tools".split())
_SERVICE_TERMS = {
    "spotify": "spotify music song track playlist playback",
    "calendar": "calendar event meeting appointment schedule",
    "gmail": "gmail email inbox",
    "docs": "docs document",
    "sheets": "sheets spreadsheet",
    "slides": "slides presentation",
    "drive": "drive file folder",
    "chat": "chat conversation",
    "people": "people contact directory",
}
_OPERATION = re.compile(r"^- `([A-Za-z][A-Za-z0-9]+)`:", re.MULTILINE)


def words(text: str) -> set[str]:
    text = re.sub(r"([a-z])([A-Z])", r"\1 \2", text)
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    tokens = [t[:-1] if len(t) > 3 and t.endswith("s") and not t.endswith("ss") else t for t in tokens]
    return {_ALIASES.get(t, t) for t in tokens if t not in _STOP}


def service_words(integration_id: str, description: str) -> set[str]:
    text = integration_id + " " + description
    for service, terms in _SERVICE_TERMS.items():
        if service in integration_id.split("_") or service in description.lower().split():
            text += " " + terms
    return words(text)


def operations(tool: Tool) -> dict[str, str]:
    description = tool.description or ""
    if "requests" not in tool.input_schema.get("properties", {}) or "list of possible updates" not in description:
        return {}
    matches = list(_OPERATION.finditer(description))
    end = description.find("\n## ", matches[-1].start()) if matches else -1
    return {m[1]: description[m.start():matches[i + 1].start() if i + 1 < len(matches)
                             else end if end >= 0 else len(description)].strip()
            for i, m in enumerate(matches)}


@dataclass
class CatalogTool:
    name: str
    integration_id: str
    tool: Tool

    @property
    def summary(self) -> str:
        return (self.tool.description or self.tool.name).split("\n", 1)[0][:240]

    @cached_property
    def searchable(self) -> set[str]:
        return words(self.name + " " + (self.tool.description or ""))

    def description(self, query: str) -> str:
        sections = operations(self.tool)
        if len(self.tool.description or "") < 8000 or not sections:
            return self.tool.description or self.tool.name
        tokens = words(query)
        scores = {op: 3 * len(tokens & words(op)) + len(tokens & words(section))
                  for op, section in sections.items()}
        best = max(scores.values(), default=0)
        selected = [op for op in sorted(sections, key=lambda op: -scores[op])
                    if scores[op] > 0 and scores[op] >= best * 0.75][:2]
        guide = self.summary + "\nEach requests item wraps one operation: {\"operationName\": {\"arguments\": ...}}."
        if "replaceAllText" in selected:
            guide += '\nExample: {"requests":[{"replaceAllText":{"containsText":{"text":"old","matchCase":true},"replaceText":"new"}}]}. Do not add a criteria wrapper.'
        tail = (self.tool.description or "").find("\n## ")
        if tail >= 0:
            guide += (self.tool.description or "")[tail:].removesuffix("-->\n").removesuffix("-->")
        if selected:
            guide += "\n" + "\n".join(sections[op] for op in selected)
        else:
            guide += "\nFetch operation guidance with get_tool_help before constructing requests. Operations: " + ", ".join(sections)
        return guide

    def invalid_arguments(self, arguments: dict) -> dict | None:
        error = next(Draft202012Validator(self.tool.input_schema).iter_errors(arguments), None)
        if error:
            return {"reason": "invalid_arguments", "path": list(error.absolute_path), "constraint": error.validator}
        sections = operations(self.tool)
        if sections and "requests" in self.tool.input_schema.get("properties", {}):
            requests = arguments.get("requests")
            if not isinstance(requests, list) or not requests:
                return {"reason": "invalid_arguments", "path": ["requests"], "constraint": "nonempty_batch"}
            for i, request in enumerate(requests):
                if not isinstance(request, dict) or len(request) != 1 or next(iter(request)) not in sections or not isinstance(next(iter(request.values())), dict):
                    return {"reason": "invalid_arguments", "path": ["requests", i], "constraint": "operation_wrapper"}
                if "replaceAllText" in request:
                    body = request["replaceAllText"]
                    criteria = body.get("containsText", {})
                    if not isinstance(criteria, dict) or not isinstance(criteria.get("text"), str) or not isinstance(body.get("replaceText"), str):
                        return {"reason": "invalid_arguments", "path": ["requests", i, "replaceAllText"], "constraint": "text_replacement"}
        return None


def search(entries: list[CatalogTool], query: str) -> list[CatalogTool]:
    tokens = words(query)
    if not tokens & {"read", "list", "search", "create", "update", "replace", "delete", "send", "play", "pause"}:
        tokens |= {"read", "list"}
    corpus = [entry.searchable for entry in entries]
    weights = {t: math.log(1 + len(entries) / (1 + sum(t in doc for doc in corpus))) for t in tokens}
    scores = []
    for entry, doc in zip(entries, corpus):
        name = words(entry.tool.name)
        score = sum(weights[t] * (3 if t in name else 1) for t in tokens & doc)
        if score:
            scores.append((score, entry.name, entry))
    return [entry for _, _, entry in sorted(scores, key=lambda row: (-row[0], row[1]))]


def schema_size(entry: CatalogTool, query: str) -> int:
    return len(json.dumps({"name": entry.name, "description": entry.description(query),
                           "parameters": entry.tool.input_schema}).encode())


def model_schema(schema: dict) -> dict:
    """Expand local references for models; execution validates the canonical schema."""
    def expand(value, seen=()):
        if isinstance(value, list):
            return [expand(v, seen) for v in value]
        if not isinstance(value, dict):
            return value
        ref = value.get("$ref", "")
        if isinstance(ref, str) and ref.startswith("#/") and ref not in seen:
            target = schema
            try:
                for key in ref[2:].split("/"):
                    target = target[key.replace("~1", "/").replace("~0", "~")]
            except (KeyError, TypeError):
                return copy.deepcopy(value)
            resolved = expand(target, (*seen, ref))
            siblings = expand({k: v for k, v in value.items() if k != "$ref"}, seen)
            if isinstance(resolved, dict) and set(siblings) <= {"description", "title", "default", "examples"}:
                return resolved | siblings
            return {"allOf": [resolved, siblings]}
        return {k: expand(v, seen) for k, v in value.items()}

    result = expand(copy.deepcopy(schema))
    if '"$ref"' not in json.dumps({k: v for k, v in result.items() if k != "$defs"}):
        result.pop("$defs", None)
    return result


def text_replacement_tool(tool: Tool) -> Tool | None:
    if (tool.name != "update_doc" or "replaceAllText" not in operations(tool)
            or not {"documentId", "requests"} <= tool.input_schema.get("properties", {}).keys()):
        return None
    return Tool(name="replace_text", description="Replace every occurrence of text in a Google document. Applies an edit. Read the document afterwards to verify. Use this instead of update_doc for text replacement.",
                inputSchema={"type": "object", "properties": {
                    "documentId": tool.input_schema["properties"]["documentId"],
                    "findText": {"type": "string"}, "replaceText": {"type": "string"},
                    "matchCase": {"type": "boolean"},
                }, "required": ["documentId", "findText", "replaceText", "matchCase"], "additionalProperties": False})
